#include "insta.h"
#include "delay.h"
void insta_Init(void)
{
 GPIO_InitTypeDef  GPIO_InitStructure;
 	
 RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
 
 GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9|GPIO_Pin_8|GPIO_Pin_10;			
 GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP; 		 //�������
 GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;		 //IO���ٶ�Ϊ50MHz
 GPIO_Init(GPIOB, &GPIO_InitStructure);					
 GPIO_ResetBits(GPIOA,GPIO_Pin_9|GPIO_Pin_8|GPIO_Pin_10);

}
 
void insta_power_on(void)
{
	u8 i;
	Insta_open=1;
	delay_ms(1000);
	for(i = 0; i<240; i++)
	{
		Insta_open=0;
		delay_ms(1);
		Insta_open=0;
		delay_ms(6);
	}
	Insta_open=1;
}
void insta_power_off(void)
{
	u16 i;
	Insta_open=0;
	for(i = 0; i<240; i++)
	{
		Insta_open=1;
		delay_ms(1);
		Insta_open=0;
		delay_ms(6);
	}
	Insta_open=1;
}
void insta_start_record(void)
{
	u8 i;
	Insta_open=0;
	for(i = 0; i<240; i++)
	{
		Insta_open=1;
		delay_ms(3);
		Insta_open=0;
		delay_ms(4);
	}
	Insta_open=1;
}

