#include "BS1088.h"
#include "delay.h"
/*
控制BS1088点阵，包括相关的初始化和对应的流水时间戳代码-与788BGG相通
时间戳方案可考虑为十六进制的方案16*16=256
上面两排逐个显示高位，下面两排逐个显示低位
管脚口：
点阵1~8：   PB9~PB5,PA12,PA11,PA10      //JTAG复用原因舍弃中间三个
点阵9~16：  PA7~PA0
正负极：
+：A7,A2,A10,A4,B9,A11,B8,B5
-: A3,B7,B6,A6,A12,A5,A1,A0


新版本788BGG接线板控制
与PCB第一版本PCB配合使用

A+:     PA0
B+:     PA1
C+:     PA2
EN+,EN-:PA3
A-:     PA4
B-:     PA5
C-:     PA6
*/

//初始化相关管脚口为输出.并使能时钟	    
//BS1088点阵IO初始化,788AB等同类型点阵管脚口连接是相同的
void BS1088_Init(void)
{
    GPIO_InitTypeDef  GPIO_InitStructure;
        
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);//使能PB,PE端口时钟
     //面包板测试   
    // GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0|GPIO_Pin_1|GPIO_Pin_2|GPIO_Pin_3|GPIO_Pin_4|GPIO_Pin_5|GPIO_Pin_6;				 //LED0-->PC13 端口配置
    // GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP; 		 //推挽输出
    // GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;		 //IO口速度为50MHz
    // GPIO_Init(GPIOA, &GPIO_InitStructure);					 //根据设定参数初始化GPIOC.13
    // GPIO_SetBits(GPIOA,GPIO_Pin_0|GPIO_Pin_1|GPIO_Pin_2|GPIO_Pin_3|GPIO_Pin_4|GPIO_Pin_5|GPIO_Pin_6);						 //PC.13 输出高.
    // ENRC=0;
//手持式平台运行
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0|GPIO_Pin_1|GPIO_Pin_2|GPIO_Pin_3|GPIO_Pin_4|GPIO_Pin_5|GPIO_Pin_6|GPIO_Pin_7|GPIO_Pin_8|GPIO_Pin_9;				 //LED0-->PC13 端口配置
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP; 		 //推挽输出
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;		 //IO口速度为50MHz
    GPIO_Init(GPIOA, &GPIO_InitStructure);					 //根据设定参数初始化GPIOC.13
    GPIO_SetBits(GPIOA,GPIO_Pin_0|GPIO_Pin_1|GPIO_Pin_2|GPIO_Pin_3|GPIO_Pin_6|GPIO_Pin_7|GPIO_Pin_8|GPIO_Pin_9);						 //PC.13 输出高
    //GPIO_ResetBits(GPIOA,GPIO_Pin_4);
    ENRC=1;
}


void BS_ON(u8 Row,u8 Col)
{
    RowA = Row & 0x0001;
    RowB = (Row >> 1) & 0x0001;
    RowC = (Row >> 2) & 0x0001;
    RowD = (Row >> 3) & 0x0001;

    ColA = ~ (Col & 0x0001);
    ColB = ~ ((Col >> 1) & 0x0001);
    ColC = ~ ((Col >> 2) & 0x0001);
    
}

void BS_OFF()
{
    ENRC = 0;	
}

void BS_Bit_Flow(u16 Delay_T)
{
    u8 Row,Col;
    for(Row=0;Row<=10;Row++)
    {
        for(Col=0;Col<=7;Col++)
        {
            BS_ON(Row,Col);
            delay_ms(Delay_T);//调整延时时间
            BS_OFF();
            delay_ms(Delay_T);//调整延时时间
        }
    }

}

void BS_Bit_Time(u16 Delay_T)
{
    u16 i;
    for(i=0;i<1225;i++)
    {
        delay_ms(Delay_T);
        if(i%2==0)
        {
            BS_ON((i/35)/7,(i/35)%7+1);
        }else{
            BS_ON((i%35+1)/7+5,(i%35+1)%7+1);  
        }
    }
}









