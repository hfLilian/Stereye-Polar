#ifndef _BS1088_H
#define _BS1088_H
#include "sys.h"

// #define RowA PAout(0)
// #define RowB PAout(1)
// #define RowC PAout(2)

// #define ENRC PAout(3)

// #define ColA PAout(4)
// #define ColB PAout(5)
// #define ColC PAout(6)
#define RowA PAout(7)
#define RowB PAout(6)
#define RowC PAout(5)
#define RowD PAout(4)

#define ColA PAout(3)
#define ColB PAout(2)
#define ColC PAout(1)

#define ENRC PAout(0)


void BS1088_Init(void);

void BS_ON(u8 Row,u8 Col);
void BS_OFF(void);

void BS_Bit_Flow(u16 Delay_T);
void BS_Bit_Time(u16 Delay_T);
#endif
