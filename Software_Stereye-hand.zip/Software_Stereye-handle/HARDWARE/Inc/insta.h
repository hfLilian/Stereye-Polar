#ifndef __INSTA_H
#define __INSTA_H	 
#include "sys.h"

#define Insta_start PAout(8)
#define Insta_open PAout(9)
#define Insta_switch PAout(10)
void insta_Init(void);//��ʼ��
void insta_power_on(void);
void insta_start_record(void);
void insta_power_off(void);

#endif
