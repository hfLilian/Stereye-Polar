#include "led.h"
#include "delay.h"
#include "key.h"
#include "sys.h"
#include "adc.h"
#include "usart.h"
#include "timer.h"
#include "INA3221.h"
#include "exti.h"
#include "usb_lib.h"
#include "hw_config.h"
#include "usb_pwr.h"

/*
Ports:
KEY:
	KEY1: PA4,3.3V; PA6,GND   ---Power
	KEY2: PA3,3.3V; PA7,GND	 ---Scan
	
RELED:(RGV)
	RGLED1: PB0 , PB8 , 5V 
	RGLED2: PB1 , PB9 , 5V
	
UART:
	TX:PA9
	RX:PA10
	
IIC:
	SCL:PB6
	SDA:PB7

ON_OFF_State:
	PA8

*/


/*
State of KEY:
0: default		Nothing
1: starting		wrinking
2: ON					ON
3: stoping		wrinking
4: OFF				OFF
5: Error			fast wrinking
*/
int KEY1_LED_State=0; //Power
int KEY2_LED_State=0;
int KEY2_STATE=0;
u16 led0pwmval=0;
u8 Time=0;
u8 dir=1;	
/*
State of RGLED:
0: default		Noting
1: >19				Green
2: >18				Yellow
3: >16				Red
4: >0 				Red wrinking
5: No					OFF					
*/
int RGLED1_State=0;
int RGLED2_State=0;
int Master_State=OFF;
int RLED1_State=0;
int GLED1_State=0;	
int RLED2_State=0;
int GLED2_State=0;
int LED_N_State=0;
int LED_P_State=0;

int main(void)
 {		
 	
	u16 Bat1=0;
	u16 Bat2=0;
	u16 Bus=0;
	u16 Voltage_Host_LED=1000;
	
	delay_init();	    	 //��ʱ������ʼ��	  
	  //
	NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2); 	 //����NVIC�жϷ���2:2λ��ռ���ȼ���2λ��Ӧ���ȼ�
	uart_init(115200);	 //���ڳ�ʼ��Ϊ115200
 	LED_Init();			     //LED�˿ڳ�ʼ��
	
	INA3221_Init();
 	TIM3_PWM_Init(6000,0);	 //����Ƶ��PWMƵ��=72000000/900=80Khz
	TIM2_PWM_Init(6000,0);
	Adc_Init();		  		//ADC��ʼ��
	USB_Port_Set(0); 	//USB�ȶϿ�
	delay_ms(1000);
	USB_Port_Set(1);	//USB�ٴ�����
 	Set_USBClock();   
 	USB_Interrupts_Config();    
 	USB_Init();	 
	 //delay_ms(1000);
	 EXTIX_Init();
	 ENABLE_24V=1;
   while(1)
	{
		//Time Control
 		delay_ms(100);	
		Time++;
		workpoint(1);		
		//if(RGLED1_State==0){TIM_SetCompare3(TIM3,led0pwmval);RG_LED1G=1;}
		//if(RGLED2_State==0){TIM_SetCompare4(TIM3,led0pwmval);RG_LED1G=1;}
		
		if(Time%10==0){
			Bat1=INA3221_GetVoltage(INA3221_ADDR1,1);
			if(Bat1>16500){
				GLED1_State=Bat1-16500;
				RLED1_State=5500-GLED1_State;
				TIM_SetCompare3(TIM3,RLED1_State);//B0
				TIM_SetCompare2(TIM2,GLED1_State);//A1
			}
			else if(Bat1>16000){
				TIM_SetCompare2(TIM2,0);
				TIM_SetCompare3(TIM3,led0pwmval);
			}
			else{
				TIM_SetCompare3(TIM3,0);
				TIM_SetCompare2(TIM2,0);
			}
				
			Bat2=INA3221_GetVoltage(INA3221_ADDR1,2);
			if(Bat2>16500){
				GLED2_State=Bat2-16500;
				RLED2_State=5500-GLED2_State;
				TIM_SetCompare4(TIM3,RLED2_State);//B1
				TIM_SetCompare2(TIM3,GLED2_State);//B5
			}
			else if(Bat2>16000){
				TIM_SetCompare2(TIM3,0);
				TIM_SetCompare4(TIM3,led0pwmval);
			}
			else{
				TIM_SetCompare4(TIM3,0);
				TIM_SetCompare2(TIM3,0);
			}
			
			
			Bus=INA3221_GetVoltage(INA3221_ADDR1,3);
			usb_printf("####battery,bat1:%d,bat2:%d,bus:%d,kled1:%d,kled2:%d****\r\n",Bat1,Bat2,Bus,KEY1_LED_State,KEY2_LED_State);
		}		
		
		//������LED������ѹ�ж�
		Voltage_Host_LED=Get_Adc(2);
		//usb_printf("Voltage_Host_LED:%d,%d\r\n",Voltage_Host_LED,KEY2);
		
		if(Voltage_Host_LED>700)LED_N_State=1;
		else LED_N_State=0;
		
		//usb_printf("Voltage_Host_LED:%d\r\n",Voltage_Host_LED);
		//�����˿��ػ��жϣ���LED������ѹ��LED������ѹ������߼��ж�
		if(  ( LED_N_State==1 && KEY2==1 )  ||  (KEY2==0) ) Master_State=OFF;
		else if( Master_State==OFF && (LED_N_State==0 && KEY2==1) ) Master_State=Open;
		if(KEY2_STATE==0)KEY2_LED_State=0;
		
		switch(Master_State){
			case ON:KEY2_LED_State=1;break;				//Device	ON
			case OFF:KEY2_LED_State=0;break;			//Device	OFF
			case Open:KEY2_LED_State=3;break;			//Device	Open
			case ShutDown:KEY2_LED_State=3;break;	//Device	ShutDown
			case Error:KEY2_LED_State=2;break;		//Device	Error
			default:break;
		}
		
		//����״̬
		if(KEY2_LED_State==2){KEY2_LED=!KEY2_LED;}
		if(KEY1_LED_State==5){KEY1_LED=!KEY1_LED;}//Scan Error
		if(KEY1_LED_State==6){
					if(Time==0)KEY1_LED=1;
					else if(Time==25)KEY1_LED=0;
					}
		//����or��or��
		if(Time%5==0){
			STM_State=!STM_State;
			//Switch KEY2
			switch(KEY2_LED_State){
				case 0:{KEY2_LED=0;break;}
				case 1:{KEY2_LED=1;break;}
				case 2:{KEY2_LED=!KEY2_LED;break;}
				case 3:{KEY2_LED=!KEY2_LED;break;}
				
				default: break;
				
					
				
			}
			//Switch KEY1
			switch(KEY1_LED_State){
				case 1:{KEY1_LED=!KEY1_LED;break;}//Scan Pending
				case 2:{KEY1_LED=1;break;}				//Scan Normal
				case 3:{KEY1_LED=!KEY1_LED;break;}//Scan Stoping
				case 4:{KEY1_LED=0;break;}				//Scan Finish
				default: break;
			}
		}

	}	 
 }
void workpoint(u8 work_indicate)
{
	if(Time>=30) Time=0;
		
		//LED Duty Control
		if(dir)led0pwmval+=50;
		else led0pwmval-=50;
 		if(led0pwmval>=(500*work_indicate))dir=0;
		if(led0pwmval<=0)dir=1;				
		
}
			/*if(Bat2>19000){
				RGLED2_State=1;
			}else if(Bat2>18000){
				RGLED2_State=2;
			}else if(Bat2>17000){
				RGLED2_State=3;
			}else if(Bat2>1000){
				RGLED2_State=4;
			}else {
				RGLED2_State=5;
			}
			//Switch RGLED2
			switch(RGLED2_State){
				case 1:{TIM_SetCompare4(TIM3,0	);RG_LED2G=0;break;}
				case 2:{TIM_SetCompare4(TIM3,7000 );RG_LED2G=0;break;}
				case 3:{TIM_SetCompare4(TIM3,7000	);RG_LED2G=1;break;}
				case 4:{TIM_SetCompare4(TIM3,led0pwmval);RG_LED2G=1;break;}
				case 5:{TIM_SetCompare4(TIM3,0	);RG_LED2G=1;break;}
				default: break;
			}		*/
